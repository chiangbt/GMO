create function raster_overlap(raster, raster) returns boolean
    immutable
    strict
    language sql
as
$$
select $1::geometry && $2::geometry
$$;

alter function raster_overlap(raster, raster) owner to postgres;

