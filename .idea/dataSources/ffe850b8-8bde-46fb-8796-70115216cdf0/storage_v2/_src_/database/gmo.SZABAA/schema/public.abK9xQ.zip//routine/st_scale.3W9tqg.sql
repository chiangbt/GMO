create function st_scale(geometry, double precision, double precision) returns geometry
    immutable
    strict
    language sql
as
$$
SELECT ST_Scale($1, $2, $3, 1)
$$;

comment on function st_scale(geometry, double precision, double precision) is 'args: geomA, XFactor, YFactor - Scales the geometry to a new size by multiplying the ordinates with the parameters. Ie: ST_Scale(geom, Xfactor, Yfactor, Zfactor).';

alter function st_scale(geometry, double precision, double precision) owner to postgres;

