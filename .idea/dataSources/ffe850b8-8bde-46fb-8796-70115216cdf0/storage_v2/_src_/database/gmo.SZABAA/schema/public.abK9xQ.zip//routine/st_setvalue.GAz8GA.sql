create function st_setvalue(rast raster, nband integer, geom geometry, newvalue double precision) returns raster
    immutable
    language sql
as
$$
SELECT st_setvalues($1, $2, ARRAY[ROW($3, $4)]::geomval[], FALSE)
$$;

comment on function st_setvalue(raster, integer, geometry, double precision) is 'args: rast, bandnum, geom, newvalue - Returns modified raster resulting from setting the value of a given band in a given columnx, rowy pixel or the pixels that intersect a particular geometry. Band numbers start at 1 and assumed to be 1 if not specified.';

alter function st_setvalue(raster, integer, geometry, double precision) owner to postgres;

