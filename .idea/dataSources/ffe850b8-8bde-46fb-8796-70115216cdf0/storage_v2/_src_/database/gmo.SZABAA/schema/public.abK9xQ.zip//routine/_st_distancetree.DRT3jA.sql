create function _st_distancetree(geography, geography) returns double precision
    immutable
    strict
    language sql
as
$$
SELECT _ST_DistanceTree($1, $2, 0.0, true)
$$;

alter function _st_distancetree(geography, geography) owner to postgres;

