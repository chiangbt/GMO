create function st_polyfromwkb(bytea) returns geometry
    immutable
    strict
    language sql
as
$$
SELECT CASE WHEN geometrytype(ST_GeomFromWKB($1)) = 'POLYGON'
	THEN ST_GeomFromWKB($1)
	ELSE NULL END

$$;

alter function st_polyfromwkb(bytea) owner to postgres;

