create function _st_asgeojson(integer, geometry, integer, integer) returns text
    immutable
    strict
    language sql
as
$$
SELECT ST_AsGeoJson($2::geometry, $3::int4, $4::int4);
$$;

alter function _st_asgeojson(integer, geometry, integer, integer) owner to postgres;

