create function st_linecrossingdirection(geom1 geometry, geom2 geometry) returns integer
    immutable
    language sql
as
$$
SELECT CASE WHEN NOT $1 && $2 THEN 0 ELSE _ST_LineCrossingDirection($1,$2) END
$$;

comment on function st_linecrossingdirection(geometry, geometry) is 'args: linestringA, linestringB - Given 2 linestrings, returns a number between -3 and 3 denoting what kind of crossing behavior. 0 is no crossing.';

alter function st_linecrossingdirection(geometry, geometry) owner to postgres;

