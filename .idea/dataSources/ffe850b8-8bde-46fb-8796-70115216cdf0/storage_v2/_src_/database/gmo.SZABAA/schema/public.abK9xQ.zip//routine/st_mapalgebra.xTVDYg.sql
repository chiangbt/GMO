create function st_mapalgebra(rast raster, nband integer, pixeltype text, expression text, nodataval double precision DEFAULT NULL::double precision) returns raster
    stable
    language sql
as
$$
SELECT _st_mapalgebra(ARRAY[ROW($1, $2)]::rastbandarg[], $4, $3, 'FIRST', $5::text)
$$;

alter function st_mapalgebra(raster, integer, text, text, double precision) owner to postgres;

